//
//  main.cpp
//  practica_4_texturas
//
//  Created by luis Orts Ferrer on 3/11/22.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
